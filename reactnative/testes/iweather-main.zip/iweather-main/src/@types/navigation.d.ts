export declare global {
  namespace ReactNavigation {
    interface RootParamList {
      search: undefined;
      dashboard: undefined;
    }
  }
}