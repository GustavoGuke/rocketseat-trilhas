module.exports = {
  jwt: {
    secret: "rodrigo",
    expiresIn: "10s"
  },
};