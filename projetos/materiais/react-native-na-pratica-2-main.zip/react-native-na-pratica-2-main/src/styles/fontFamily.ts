export const fontFamily = {
  regular: "OpenSans_400Regular",
  semiBold: "OpenSans_600SemiBold",
  bold: "OpenSans_700Bold",
}
