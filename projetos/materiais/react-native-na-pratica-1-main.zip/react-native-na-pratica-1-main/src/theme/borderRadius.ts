export const borderRadius = {
  sm: 5,
  md: 10,
  lg: 20,
  full: 999,
}
