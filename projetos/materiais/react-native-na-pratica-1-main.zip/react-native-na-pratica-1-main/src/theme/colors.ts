export const colors = {
  white: "#FFFFFF",
  black: "#000000",

  green_100: "#DCFCE7",
  green_600: "#15803D",

  yellow_500: "#EFB103",

  gray_200: "#C4C4CC",
  gray_300: "#8D8D99",
  gray_400: "#7C7C8A",
}
