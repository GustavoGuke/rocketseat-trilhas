import { LandingPage } from '@/templates/landing-page';

export default function Home() {
  return <LandingPage />;
}
